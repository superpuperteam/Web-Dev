//task1
var admin;
var name; 
name = "John";
admin = name;
alert(admin); 

//task2
var ourplanet = "Universe";
// let ourplanet = "Universe";

//task3
let username = "Salta";
// var username = "Salta";

//task4
const BIRTHDAY = '31.05.2005';
const age = someCode(BIRTHDAY);

