
//task1
let name = 'Ilya';

alert(`hello ${1}`);
alert(`hello ${"name"}`);
alert(`hello ${name}`); 

//task2
